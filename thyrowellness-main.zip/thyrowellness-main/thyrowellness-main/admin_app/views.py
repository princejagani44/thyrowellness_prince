from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.template import loader

from .API import *
from django.contrib.auth.decorators import login_required


from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from api_app.models import *
import io
from django.contrib import messages
from django.contrib.auth import logout,login,authenticate,update_session_auth_hash
from django.shortcuts import render,redirect
from django.core.mail import send_mail
from django.conf import settings


########################################################################################################
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
import sys,os
from django.contrib.auth.forms import PasswordChangeForm
import math,random

from datetime import datetime
from supportfile import *


# Create your views here.

# admin Controle
@login_required
def adminIndex(request):
    print(request.session['username'],'aaaaaaaaaaaaaaaaaaaaa')
    return render(request,'dashboard.html', {'dashboard_active':'active'})

@login_required
def home_slider(request):
    return render(request,'home_slider.html', {'home_slider_active':'active'})



# category page All Functions
def category(request):
    try:
        showCategory = categoryProduct.objects.all()
        return render(request,'category/category.html',{'showCategory':showCategory, 'baseURL':baseUrl, 'category_active':'active'})
    except Exception as e:
        print(e)
        return render(request,'404.html')
   

def addCategory(request):   
    if request.method == 'POST':
        categoryNames=request.POST.get('categoryname')
        categoryIcon=request.FILES['categoryIcon']

        logUser=categoryProduct()
        logUser.categoryName=categoryNames
        logUser.categoryIcon=categoryIcon          
        logUser.save()
        return redirect('category')

    else:
        return render(request,'404.html')


def updateCategory(request, pk):
    try :
        category=categoryProduct.objects.get(pk=pk)
        if request.method=='POST':
            category.categoryName=request.POST['categoryname']
            try:
                category.categoryIcon=request.FILES['categoryIcon']
            except:
                pass

            category.save()

            return redirect('category')
        else:
            showCategory = categoryProduct.objects.all()
            return render(request,'category/category.html',{'showCategory':showCategory, 'data':category, 'baseURL':baseUrl, 'category_active':'active'})
    except Exception as e:
        print(e)
        return render(request,'404.html')


def deleteCategory(request, pk):
    try:
        member = categoryProduct.objects.get(pk=pk)
        member.delete()
        return redirect('category')
    except:
        return render(request,'404.html')


def  changeStatus(request, id):
    try:
        get_data = categoryProduct.objects.get(id=id)
        if get_data.status == "True":
            get_data.status="False"
        else:
            get_data.status="True"

        get_data.save()
        return redirect('category')
    except Exception as e:
        print(e)
        return render(request,'404.html')
    
def  change_state_review(request, id):
    try:
        get_data = DoctorReview.objects.get(id=id)
        if get_data.status == "True":
            get_data.status="False"
        else:
            get_data.status="True"

        get_data.save()
        return redirect('doctorreview')
    except Exception as e:
        print(e)
        return render(request,'404.html')

# End Category Page Function

#start Product Page Function
@login_required
def products(request):
    try:
        users = User.objects.all()
        category = categoryProduct.objects.all()
        showProduct = Product.objects.all()
        return render(request,'products/product.html',{'showProduct':showProduct, "category":category , "users":users , 'baseURL':baseUrl, 'products_active':'active', 'detail_active':'active'})
    except Exception as e:
        print(e)
        return render(request,'404.html')

def addProduct(request):
    if request.method == 'POST':
        print(request.FILES)
        userid=request.POST.get('userid')
        categoryid=request.POST.get('categoryid')
        productName=request.POST.get('productName')
        productDescription=request.POST.get('productDescription')
        productImages=request.FILES['productImages']
        productTamlen=request.FILES['productTamlen']
        productPrice=request.POST.get('productPrice')
        productQty=request.POST.get('productQty')
        gstTax=request.POST.get('gstTax')
        productMetaTitle=request.POST.get('productMetaTitle')

        now = datetime.now()

        current_time = now.strftime("%H:%M:%S")

        userdata = User.objects.get(id=userid)
        categorydata = categoryProduct.objects.get(id=categoryid)
        logUser=Product()
        logUser.userId=userdata
        logUser.categoryId=categorydata
        logUser.productName=productName
        logUser.productDescription=productDescription
        logUser.productImages=productImages
        logUser.productTamlen=productTamlen
        logUser.productPrice=productPrice
        logUser.gstTax=gstTax
        logUser.productDiscountPercentage=request.POST.get('productDiscountPercentage')
        logUser.productDiscountPrice=request.POST.get('productDiscountPrice')
        logUser.productFinalPrice=request.POST.get('productFinalPrice')
        logUser.productQty=productQty
        logUser.productMetaTitle=productMetaTitle
        logUser.save()

        return redirect('products')

    else:
        return render(request,'404.html')

def updateProduct(request, pk):
    print(pk)
    try :
        Products=Product.objects.get(pk=pk)
        if request.method=='POST':
            userid=request.POST.get('userid')
            categoryid=request.POST.get('categoryid')

            userdata = User.objects.get(id=userid)
            categorydata = categoryProduct.objects.get(id=categoryid)

            Products.userId=userdata
            Products.categoryId=categorydata
            Products.productName=request.POST.get('productName')
            Products.productDescription=request.POST.get('productDescription')
            Products.productPrice=request.POST.get('productPrice')
            Products.productQty=request.POST.get('productQty')
            Products.productMetaTitle=request.POST.get('productMetaTitle')
            
            Products.gstTax=request.POST.get('gstTax')
            Products.productDiscountPercentage=request.POST.get('productDiscountPercentage')
            Products.productDiscountPrice=request.POST.get('productDiscountPrice')
            Products.productFinalPrice=request.POST.get('productFinalPrice')
            try:
                Products.productImages=request.FILES['productImages']
            except:
                pass
            try:
                Products.productTamlen=request.FILES['productTamlen']
            except:
                pass
            Products.save()

            return redirect('products')
        else:
            return redirect('products')
    except Exception as e:
        print(e)
        return render(request,'404.html')

def deleteProduct(request, pk):
  member = Product.objects.get(pk=pk)
  member.delete()
  return redirect('products')

def stockmanage(request):
    try:
        showProductStock = ProductStock.objects.all()
        Products = Product.objects.all()
        return render(request,'products/stockmanage.html',{'showProductStock':showProductStock, "Product":Products, 'products_active':'active', 'stockmanage_active':'active'})
    except:
        return render(request,'404.html')

def addProductStock(request):   
    if request.method == 'POST':
        productId=request.POST.get('productId')
        Variant=request.POST.get('Variant')
        pushesQty=request.POST.get('pushesQty')
        soldQty=request.POST.get('soldQty')
        stockQty=request.POST.get('stockQty')
        unitPrice=request.POST.get('unitPrice')
        sealsPrice=request.POST.get('sealsPrice')
        Price=request.POST.get('Price')
        serialNumber=request.POST.get('serialNumber')

        Get_Product = Product.objects.get(id=productId)
        proStock=ProductStock()
        proStock.productId=Get_Product
        proStock.Variant=Variant
        proStock.pushesQty=pushesQty
        proStock.soldQty=soldQty
        proStock.stockQty=stockQty
        proStock.unitPrice=unitPrice
        proStock.sealsPrice=sealsPrice
        proStock.Price=Price
        proStock.serialNumber=serialNumber
        proStock.save()

        return redirect('stockmanage')

    else:
        return render(request,'404.html')


def updateProductStock(request, pk):
    print("h1")
    try :
        upStock=ProductStock.objects.get(pk=pk)
        if request.method=='POST':
            Get_Product = Product.objects.get(id=request.POST.get('productId'))
            upStock.productId=Get_Product
            upStock.Variant=request.POST.get('Variant')
            upStock.pushesQty=request.POST.get('pushesQty')
            upStock.soldQty=request.POST.get('soldQty')
            upStock.stockQty=request.POST.get('stockQty')
            upStock.unitPrice=request.POST.get('unitPrice')
            upStock.sealsPrice=request.POST.get('sealsPrice')
            upStock.Price=request.POST.get('Price')
            upStock.serialNumber=request.POST.get('serialNumber')

            upStock.save()

            return redirect('stockmanage')
        else:
            pass
    except Exception as e:
        print(e)
        return render(request,'404.html')



def deleteProductstock(request, pk):
  member = ProductStock.objects.get(pk=pk)
  member.delete()
  return redirect('stockmanage')

def order(request):
    order_data = Order.objects.all()
    Product_data = ProductStock.objects.all()

    return render(request, 'order/order.html', {'order_active':'active', 'orders':order_data, 'products':Product_data, 'baseURL':baseUrl})


def addOrder(request):   
    if request.method == 'POST':
        orderId=request.POST.get('orderId')
        orderQty=request.POST.get('orderQty')
        tranctionNumber=request.POST.get('tranctionNumber')
        deliveryCharge=request.POST.get('deliveryCharge')
        orderstatus=request.POST.get('orderstatus')
        paymentMethod=request.POST.get('paymentMethod')
        tranctionId=request.POST.get('tranctionId')
        shipingInfo=request.POST.get('shipingInfo')
        billingInfo=request.POST.get('billingInfo')
        paymentstatus=request.POST.get('paymentstatus')
        orderComment=request.POST.get('orderComment')

        ProductStockData = ProductStock.objects.get(id=request.POST.get('ProductStockId'))
        
        ProductStockData.soldQty += int(orderQty)
        ProductStockData.stockQty -= int(orderQty)
        ProductStockData.save()
        ProductStockData = ProductStock.objects.get(id=request.POST.get('ProductStockId'))
        # stock_data = ProductStock.objects.get(serialNumber=productData.)
        proOrder=Order()
        proOrder.ProductStockId=ProductStockData
        proOrder.orderId=orderId
        proOrder.orderQty=orderQty
        proOrder.tranctionNumber=tranctionNumber
        proOrder.deliveryCharge=deliveryCharge
        proOrder.orderstatus=orderstatus
        proOrder.paymentMethod=paymentMethod
        proOrder.tranctionId=tranctionId
        proOrder.shipingInfo=shipingInfo
        proOrder.billingInfo=billingInfo
        proOrder.paymentstatus=paymentstatus
        proOrder.orderComment=orderComment

        proOrder.save()

        return redirect('order')

    else:
        return render(request,'404.html')



def updateOrder(request, pk):
    try :
        upOrder=Order.objects.get(pk=pk)
        if request.method=='POST':
            productData = ProductStock.objects.get(id=request.POST.get('ProductStockId'))
            upOrder.ProductStockId=productData
            upOrder.orderId=request.POST.get('orderId')
            upOrder.orderQty=request.POST.get('orderQty')
            upOrder.tranctionNumber=request.POST.get('tranctionNumber')
            upOrder.deliveryCharge=request.POST.get('deliveryCharge')
            upOrder.orderstatus=request.POST.get('orderstatus')
            upOrder.paymentMethod=request.POST.get('paymentMethod')
            upOrder.tranctionId=request.POST.get('tranctionId')
            upOrder.shipingInfo=request.POST.get('shipingInfo')
            upOrder.billingInfo=request.POST.get('billingInfo')
            upOrder.paymentstatus=request.POST.get('paymentstatus')
            upOrder.orderComment=request.POST.get('orderComment')

            upOrder.save()
            return redirect('order')
        else:
            return redirect('order')
    except Exception as e:
        print(e)
        return render(request,'404.html')


def deleteOrder(request, pk):
    member = Order.objects.get(pk=pk)
    member.delete()
    return redirect('order')


def Cart(request):    
    try:
        allUsers = User.objects.all()
        for user in allUsers:
            Usercart = UserCart.objects.filter(user=user)
            if len(Usercart)==0:
                pass
            else:
                user.total_iteam = len(Usercart)
                user.cart = list(Usercart)
        return render(request,'cart/admincart.html',{'cart_active':'active','showCarts':allUsers})
    except Exception as e:
        print(e)
        return render(request,'404.html')


# def get_cart_detail(request):



def addCart(request, id):   
    if request.method=="POST":  
        # if request.user.is_authenticated:

        user = User.objects.get(id=request.POST['userid'])
        product=Product.objects.get(id=request.POST['productid'])

        db_cart=UserCart()
        db_cart.user = user
        db_cart.product = product
        db_cart.orderQty = request.POST.get('orderQty')
        db_cart.save()
        return redirect(f'/admin_app/cartproduct/{id}')
        # else:
        #     messages.warning(request, 'login plz')

    else:
        return render(request,'404.html')


def deleteCart(request, pk):
    cartObj = UserCart.objects.get(pk=pk)
    userid = cartObj.user.id
    cartObj.delete()
    return redirect(f'/admin_app/cartproduct/{userid}')


def cartproduct(request, id):
    Userdata = User.objects.get(id=id)
    Usercart = UserCart.objects.filter(user=Userdata)

    alluser = User.objects.all()
    allproduct = Product.objects.all()

    return render(request, 'cart/cartproduct.html', {'cart_active':'active', 'Usercarts':Usercart, "Userdata":Userdata, "alluser":alluser, "allproduct":allproduct})


# User Controle
# def login(request):
#     return render(request, 'login.html')

def register(request):
    return render(request,'register.html')


from django.http import JsonResponse

def search(request):
    search_text = request.GET.get('search_text', '')
    results = Product.objects.filter(productName__icontains=search_text)
    data = [{'name': result.productName} for result in results]
    return JsonResponse(data, safe=False)


def searchpage(request):
    return render(request,'search.html')


# def add_category(request):
#     if request.method=='POST':
#         print(request.POST['iconpath'])
#         print(type(request.FILES['Icon']))

#         from django.core.files.uploadedfile import InMemoryUploadedFile

#     # def process_uploaded_file(uploaded_file: InMemoryUploadedFile):
        
#         data = {
#             "categoryname":request.POST['name'],
#             "status":request.POST['status'],
#             "categoryIcon":request.FILES['Icon'],
#             "fullpath":request.POST['iconpath']
#         },
#         response = addCategory(data)

#     return redirect('category')




# def category(request):
#     response = showCategory()
#     if response:
#         pass
#     else:
#         response = {
#             "students":[]
#         }

#     return render(request,'category.html', {'datas':response})


class blog():
    def blogshow(request):
        blogs=BlogReview.objects.all()
        return render(request,'blog.html',{"blogs":blogs})
    
    def blogadd(request):
        if request.method == 'POST':
            blogWriter=request.POST.get('blogWriter')
            blogComment=request.POST.get('blogComment')
            blogmail=request.POST.get('blogmail')

            
            blogObj=BlogReview()
            blogObj.blogWriter=blogWriter
            blogObj.blogComment=blogComment
            blogObj.blogmail=blogmail

            blogObj.save()

            return redirect('/admin_app/blog')

        else:
            return redirect('/admin_app/blog')
        
    def blogdelete(request,id):
        obj = BlogReview.objects.get(id=id)
        obj.delete()
        return redirect('/admin_app/blog')
    
    def blogupdate(request):
        if request.method=="POST":
            bw=request.POST.get('blogwriter')
            bc=request.POST.get('blogComment')
            bm=request.POST.get('blogmail')
            id=request.POST.get('upid')


            blogObj=BlogReview.objects.get(id=id)
            blogObj.blogWriter=bw
            blogObj.blogComment=bc
            blogObj.blogmail=bm
            blogObj.save()
            return redirect('/admin_app/blog')
        

class doc_review():

    def addDoctorReview(request):   
        if request.method == 'POST':
            doctorName=request.POST.get('doctorName')
            doctorDescription=request.POST.get('doctorDescription')
            doctorTitle=request.POST.get('doctorTitle')
            doctormail=request.POST.get('doctorMail')

            try:
                doctorImage=request.FILES['doctorImage']
            except:
                pass

        
            docObj=DoctorReview()
            docObj.doctorName=doctorName
            docObj.doctorDescription=doctorDescription
            docObj.doctorTitle=doctorTitle
            docObj.doctormail=doctormail
            docObj.doctorImage=doctorImage
            docObj.save()

            return redirect('/admin_app/doctorreview')

        else:
            return redirect("/admin_app/doctorreview")
        
    def showdocreview(request):
        data=DoctorReview.objects.all()
        return render(request,'doc_review.html',{"data":data})
    
    def deleteDoctorReview(request, id):
        docObj = DoctorReview.objects.get(id=id)
        docObj.delete()
        return redirect('/admin_app/doctorreview')
    
    def updateDoctorReview(request):
        try :
            id=request.POST.get('upid')
            docObj=DoctorReview.objects.get(id=id)
            if request.method=='POST':
                docObj.doctorName=request.POST.get('doctorName')
                docObj.doctorDescription=request.POST.get('doctorDescription')
                docObj.doctorTitle=request.POST.get('doctorTitle')
                docObj.doctormail=request.POST.get('doctorMail')

                try:
                    docObj.doctorImage=request.FILES['doctorImage']
                except:
                    pass

                docObj.save()

                return redirect('/admin_app/doctorreview')
            else:
                return render(request,'temp.html')
        except Exception as e:
            print(e,'hhhhhhhhhhhhhh')
            return render(request,'404.html')


def contactus(request,del_id=0,up_id=0):
    if request.method=="POST":
        writerName=request.POST.get('writerName')
        Mail=request.POST.get('Mail')
        Comment=request.POST.get('Comment')

      
        conObj=ContactUs()
        conObj.writerName=writerName
        conObj.Mail=Mail
        conObj.Comment=Comment
        conObj.save()
        return redirect('/admin_app/contactus')
    elif(del_id!=0):
        obj = ContactUs.objects.get(id=del_id)
        obj.delete()
        return redirect('/admin_app/contactus')
    
    else:
        data=ContactUs.objects.all()
        context={"data":data}
        return render(request,'contactus.html',context=context)

def upcontact(request,up_id):
    if request.method=="POST":
        writerName=request.POST.get('writerName')
        Mail=request.POST.get('Mail')
        Comment=request.POST.get('Comment')

        conObj=ContactUs.objects.get(id=up_id)
        conObj.writerName=writerName
        conObj.Mail=Mail
        conObj.Comment=Comment
        conObj.save()
        return redirect('/admin_app/contactus')
    else:
        obj = ContactUs.objects.get(id=up_id)
        context={"obj":obj}

        return render(request,'admins/contactus.html',context=context)
    
def logins(request):
        return render(request,'login.html')



def loginuser(request):  
    if request.method == 'POST':
        print('request.data')
    # return JsonResponse (request.data)
        username = request.POST.get('username')
        password = request.POST.get('password')

        # username = request.data['username']
        # password = request.data['password']

        # username = request.POST['username']
        # password = request.POST['password']
        print(request)
        print(request.POST,'00000000000000000000000')
        print(username,password,'7777777777777777')

        if username is not None and password is not None:
            # if user is not None

            if len(password)>7:

                user = authenticate(username =username, password=password)
                if user is not None:
                    request.session['username'] = username
                    print(request.session['username'],'hhhhhhh')
                    
                    login(request, user)
                    return redirect('dashboard')
                    # return render(request,"admins/index.html",context=context)

                else:
                    messages.warning(request, 'user or password not match')
                    return redirect("/admin_app/login")
            else:
                messages.warning(request, 'Enter password 8 number')
                return redirect("/admin_app/login")
        else:
            messages.warning(request, 'Enter id and password')
            return redirect("/admin_app/login")
            

    else:
        return render(request,'404.html')
    

def logout_view(request):
    
    try:

        del request.session['username']
    except Exception as e:
        print(e,'assasaass')
    logout(request)
    return redirect('/admin_app/login')