import requests
import json
from .supportfile import *

# def showCategory():
#     url = f"{baseUrl}/api_app/showCategory/"

#     payload={}
#     headers = {}

#     response = requests.request("GET", url, headers=headers, data=payload)

#     response = json.loads(response.text)
#     if response['type'] == "True":
#         return response
#     else:
#         return False


# def addCategory(data):
#     try:

#         url = "http://192.168.0.110:8000/api_app/addCategory/"

#         payload={'categoryname': data[0]['categoryname'],
#         'status': data[0]['status']},

#         files=[
#             ('categoryIcon',('erp-data-flow.jpg',open('/home/quantumbot/Desktop/erp-data-flow.jpg','rb'),'image/jpeg'))
#         ]
        
#         headers = {}

#         response = requests.request("POST", url, headers=headers, data=payload, files=files)

#         print(response.text)



#         # print("h1")
#         # url = f"{baseUrl}/api_app/addCategory/"
#         # print("h2")
#         # print(data)

        

#         # print("h3",type(data[0]['categoryIcon'].file.getvalue())),
#         # files=[
#         # ('categoryIcon',('erp-data-flow.jpg',open('/home/quantumbot/Desktop/erp-data-flow.jpg','rb'),'image/jpeg'))
#         # ]
#         # print(files)
#         # # files=[
#         # # ('categoryIcon',data[0]['categoryIcon'])
#         # # ]
#         # print("h4")
#         # headers = {}
#         # print("h5")

#         # response = requests.request("POST", url, headers=headers, data=payload, files=files)
#         # print("h6", response.text)

#         response = json.loads(response.text)
#         return response
#     # if response['type'] == "True":
#     except Exception as e:
#         print(e)
#     return False
    # else:
    #     return False