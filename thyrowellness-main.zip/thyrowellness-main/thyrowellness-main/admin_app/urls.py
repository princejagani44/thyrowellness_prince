from django.contrib import admin
from django.urls import path,include
from admin_app import views
from django.conf import settings
from django.conf.urls.static import static


urlpatterns = [
    path('dashboard/', views.adminIndex, name="dashboard"),
    path('home_slider/', views.home_slider, name="home_slider"),
    path('category/', views.category, name="category"),
    path('addCategory/', views.addCategory, name="addCategory"),
    path('category/<int:pk>', views.updateCategory, name="updateCategory"),
    path('deleteCategory/<int:pk>', views.deleteCategory, name="deleteCategory"),
    path('changeStatus/<int:id>', views.changeStatus, name="changeStatus"),

    path('products/', views.products, name="products"),
    path('addProduct/', views.addProduct, name="addProduct"),
    path('products/<int:pk>', views.updateProduct, name="updateProduct"),
    path('deleteProduct/<int:pk>', views.deleteProduct, name="deleteProduct"),
    path('stockmanage/', views.stockmanage, name="stockmanage"),
    path('addProductStock/', views.addProductStock, name="addProductStock"),
    path('stockmanage/<int:pk>', views.updateProductStock, name="updateProductStock"),
    path('deleteProductstock/<int:pk>', views.deleteProductstock, name="deleteProductstock"),
    path('order/', views.order, name="order"),
    path('addOrder/', views.addOrder, name="addOrder"),
    path('order/<int:pk>', views.updateOrder, name="updateOrder"),
    path('deleteOrder/<int:pk>', views.deleteOrder, name="deleteOrder"),

    path('Cart/', views.Cart, name="Cart"),
    path('addCart/<int:id>', views.addCart, name="addCart"),
    path('cartproduct/<int:id>', views.cartproduct, name="cartproduct"),
    path('deleteCart/<int:pk>', views.deleteCart, name="deleteCart"),
    path('search/', views.search, name="search"),
    path('searchpage/', views.searchpage, name="searchpage"),

    path('login/', views.login, name="login"),
    path('register/', views.register, name="register"),
    # path('add_category', views.add_category, name="add_category"),
    # path('test/<int:id>', views.test, name="test"),

#################################### ADDEED BY PRINCE   ########################################################
    path('blog', views.blog.blogshow, name="blog"),
    path('blogadd', views.blog.blogadd, name="blogadd"),
    path('blogdelete/<int:id>', views.blog.blogdelete, name="blogdelete"),
    path('blogupdate', views.blog.blogupdate, name="blogupdate"),
    path('doctorreview', views.doc_review.showdocreview, name="doctorreview"),
    path('addreview', views.doc_review.addDoctorReview, name="addreview"),
    path('delreview/<int:id>', views.doc_review.deleteDoctorReview, name="delreview"),
    path('upreview', views.doc_review.updateDoctorReview, name="upreview"),
    path('changeStatusReview/<int:id>', views.change_state_review, name="changeStatus"),
     path('login', views.logins, name="login"),
    path('loginuser', views.loginuser, name="loginuser"),
    # path('reset', views.ResetPassword, name="reset"),
    path('logout', views.logout_view, name="logout"),


]

urlpatterns = urlpatterns + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)

