from django.contrib import admin
from django.urls import path,include
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    # path('', views.index, name="erp_app"),
    path('showCategory/', views.showCategory, name="showCategory"),
    path('addCategory/', views.addCategory, name="addCategory"),
    path('test/<int:id>', views.test, name="test"),
    # path('deleteCategory/', views.deleteCategory, name="deleteCategory"),
    # path('updateCategory/', views.updateCategory, name="updateCategory"),
    # path('loginuser/', views.loginuser, name="loginuser"),
    # path('logoutuser/', views.logoutuser, name="logoutuser"),



 

    

  
    
    

]
urlpatterns = urlpatterns + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)