from django.db import models
from django.utils import timezone  
from django.contrib.auth.models import User

# Create your models here.

####################### api model #######################
class categoryProduct(models.Model):

    categoryName=models.CharField(max_length=100, default="")
    categoryIcon=models.ImageField(upload_to="api_app/img", default="")
    status=models.CharField(default="True", max_length=20, blank=True)
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(auto_now=True)


class Product(models.Model):
    userId=models.ForeignKey(to=User,on_delete=models.CASCADE)
    categoryId=models.ForeignKey(to=categoryProduct,on_delete=models.CASCADE)
    productName=models.CharField(max_length=200, default="")
    productDescription=models.CharField(max_length=300, default="")
    productImages=models.ImageField(upload_to="api_app/img", blank=True)
    prodproductuctTamlen=models.ImageField(upload_to="api_app/img", blank=True)
    productPrice=models.IntegerField(blank=True)

    productDiscountPercentage=models.IntegerField(blank=True)
    productDiscountPrice=models.IntegerField(blank=True)
    productFinalPrice=models.IntegerField(blank=True)
    gstTax = models.IntegerField(blank=True)

    productQty=models.IntegerField(blank=True)
    productMetaTitle=models.CharField(max_length=200, default="")
    status=models.CharField(max_length=20, default="True")
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(default=timezone.now)


class ProductStock(models.Model):
    productId=models.ForeignKey(to=Product,on_delete=models.CASCADE)
    Variant=models.CharField(max_length=200, default="")
    pushesQty=models.IntegerField()
    soldQty=models.IntegerField()
    stockQty=models.IntegerField()
    unitPrice=models.IntegerField()
    sealsPrice=models.IntegerField()
    Price=models.IntegerField()
    serialNumber=models.IntegerField()
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(default=timezone.now)


class Order(models.Model):
    ProductStockId=models.ForeignKey(to=ProductStock,on_delete=models.CASCADE)
    orderId = models.CharField(max_length=200, default="")
    orderQty=models.IntegerField()
    tranctionNumber = models.IntegerField()
    deliveryCharge = models.IntegerField()
    orderstatus= models.CharField(max_length=50, default="")
    paymentMethod = models.CharField(max_length=200, default="")
    tranctionId = models.CharField(max_length=200, default="")
    shipingInfo= models.CharField(max_length=300, default="")
    billingInfo= models.CharField(max_length=300, default="")
    paymentstatus=models.CharField(max_length=50, default="")
    orderComment=models.CharField(max_length=500, default="")
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(default=timezone.now)


class UserCart(models.Model):
    user=models.ForeignKey(to=User,on_delete=models.CASCADE)
    product=models.ForeignKey(to=Product,on_delete=models.CASCADE)
    orderQty=models.IntegerField()
    createDate=models.DateTimeField(default=timezone.now)
    updateDate=models.DateTimeField(default=timezone.now)


class ContactUs(models.Model):
    writerName=models.CharField(max_length=100, default="")
    Mail=models.CharField(max_length=100, default="")
    Comment=models.CharField(max_length=100, default="")


class BlogReview(models.Model):
    blogWriter=models.CharField(max_length=100, default="")
    blogComment=models.CharField(max_length=500, default="")
    blogmail=models.CharField(max_length=100, default="")
    createDate=models.DateTimeField(default=timezone.now)


class DoctorReview(models.Model):
    doctorName=models.CharField(max_length=100, default="")
    doctorDescription=models.CharField(max_length=1000, default="")
    doctorTitle=models.CharField(max_length=200, default="")
    doctormail=models.CharField(max_length=100, default="")
    # doctorVideo=models.FileField(upload_to="api_app/img", default="")
    doctorImage=models.ImageField(upload_to="api_app/img", default="")
    status=models.CharField(default="True", max_length=20, blank=True)
    createDate=models.DateTimeField(default=timezone.now)



