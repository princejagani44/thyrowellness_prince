from django.contrib import admin
from api_app.models import *







# Register your models here.
admin.site.register(categoryProduct)
admin.site.register(Product)
admin.site.register(ProductStock)
admin.site.register(Order)
admin.site.register(UserCart)
