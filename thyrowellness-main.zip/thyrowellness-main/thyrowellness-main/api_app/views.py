from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from .models import User,categoryProduct
from .serializers import categoryProductSerializer
from rest_framework.renderers import JSONRenderer
import io
from rest_framework.parsers import JSONParser
from django.views.decorators.csrf import csrf_exempt
from rest_framework import viewsets
from rest_framework.views import APIView
from rest_framework.authtoken.models import Token 
from django.contrib import messages
from django.contrib.auth import logout,login,authenticate,update_session_auth_hash
from django.shortcuts import render,redirect
from django.core.mail import send_mail
from django.conf import settings


########################################################################################################
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from rest_framework import status
import sys,os
from django.contrib.auth.forms import PasswordChangeForm
import math,random

from datetime import datetime
from supportfile import *
################################ all page import ################################ 



# Create your views here.

################################ category ################################ 



#################################################################################################



def showCategory(request):    
    try:
        showCategory = categoryProduct.objects.all()
        return render(request,'category.html',{'showCategory':showCategory, 'baseURL':baseUrl})
    except Exception as e:
        print(e)
        return render(request,'404.html')

def test(request, id):
    print(id)
    return redirect('showCategory')

def addCategory(request):
    if request.method == 'POST':
        categoryNames=request.POST.get('categoryname')
        statuss=request.POST.get('status')
        categoryIcon=request.FILES['categoryIcon']

        now = datetime.now()

        current_time = now.strftime("%H:%M:%S")
        logUser=categoryProduct()
        logUser.categoryName=categoryNames
        logUser.categoryIcon=categoryIcon
        logUser.status=statuss                
        logUser.save()
        return redirect('showCategory')

    else:
        return render(request,'404.html')

def login(request):
    return render(request, 'login.html')


def register(request):
    return render(request,'register.html')






















